@echo off
themedata\_internal\Scripts\python.exe themedata\_internal\activate.py